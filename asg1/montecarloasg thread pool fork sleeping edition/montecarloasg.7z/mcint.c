#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include "func.h"
#include "mytime.h"
int main(int nargs, char **args)
{
    int i;
    unsigned int hits = 0;
    double x, y, z, ms;
    double xdist, ydist, zdist, xmin, ymin, zmin, compVol;
    
    GetBoundaries(&xdist, &xmin, &ydist, &ymin, &zdist, &zmin);
    
    unsigned int N = 16000000;
    int S = 0xFCB321;
    int p = 4;
    srand48(time(NULL));

    double rectVol = xdist * ydist * zdist;

    fprintf(stdout,"%f %f %f",xmin,ymin,zmin); 
    for (i=0; i < N; i++)
    {
        x = drand48()*xdist + xmin;
        y = drand48()*ydist + ymin;
        z = drand48()*zdist + zmin;
        if (IsInFunc(x, y, z))
        {
            hits++;
        }
    }
    compVol = rectVol * hits / N;
    /*
     * Need to add timing calls to compute ms
     */
    fprintf(stdout, "rectVol = %f * %f * %f = %f\n", xdist, ydist, zdist, rectVol);
    fprintf(stdout, "N=%u, nhits=%u, %% hits = %f\n", N, hits, (hits*100.0)/(1.0*N));
    fprintf(stdout, "Time for %d iterations: %f (ms)\n", N, ms);
    fprintf(stdout, "funcVol = %lf, givenVol=%lf error=%e\n",compVol, KNOWN_VOL, fabs(compVol-KNOWN_VOL));
}
